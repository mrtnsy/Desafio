package main;
import Entities.Funcionario;

public class Main {
    public static void main(String[] args) {
        Funcionario Joao = new Funcionario();

        Joao.Funcionario(123,"jao",12/09/2000,11/10/2021,"teste");

        System.out.println("Cod Funcionario: " + Joao.getCod_funcionario());
        System.out.println("Nome Funcionario: " + Joao.getNom_funcionario());
        System.out.println("Dtn Funcionario: " + Joao.getDtn_funcionario());


    }
}