package Entities;
import java.util.Date;

public class Funcionario {

    private int cod_funcionario;
    private String nom_funcionario;
    private Date dtn_funcionario;
    private Date dta_funcionario;
    private String ctps_funcionario;



    public Funcionario(int cod_funcionario, String nom_funcionario, Date dtn_funcionario, Date dta_funcionario, String ctps_funcionario) {

        this.cod_funcionario = cod_funcionario;
        this.nom_funcionario = nom_funcionario;
        this.dtn_funcionario = dtn_funcionario;
        this.dta_funcionario = dta_funcionario;
        this.ctps_funcionario = ctps_funcionario;
    }




    public int getCod_funcionario() {
        return cod_funcionario;
    }

    public void setCod_funcionario(int cod_funcionario) {
        this.cod_funcionario = cod_funcionario;
    }

    public String getNom_funcionario() {
        return nom_funcionario;
    }

    public void setNom_funcionario(String nom_funcionario) {
        this.nom_funcionario = nom_funcionario;
    }

    public Date getDtn_funcionario() {
        return dtn_funcionario;
    }

    public void setDtn_funcionario(Date dtn_funcionario) {
        this.dtn_funcionario = dtn_funcionario;
    }

    public Date getDta_funcionario() {
        return dta_funcionario;
    }

    public void setDta_funcionario(Date dta_funcionario) {
        this.dta_funcionario = dta_funcionario;
    }

    public String getCtps_funcionario() {
        return ctps_funcionario;
    }

    public void setCtps_funcionario(String ctps_funcionario) {
        this.ctps_funcionario = ctps_funcionario;
    }
}
