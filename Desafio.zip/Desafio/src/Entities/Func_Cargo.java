package Entities;

import java.util.Date;

public class Func_Cargo {

    private int cod_funcionario;
    private int cod_cargo;
    private Date dti_func_cargo;

    public Func_Cargo(int cod_funcionario, int cod_cargo, Date dti_func_cargo){

        this.cod_funcionario = cod_funcionario;
        this.cod_cargo = cod_cargo;
        this.dti_func_cargo = dti_func_cargo;
    }


    public int getCod_funcionario() {
        return cod_funcionario;
    }

    public void setCod_funcionario(int cod_funcionario) {
        this.cod_funcionario = cod_funcionario;
    }

    public int getCod_cargo() {
        return cod_cargo;
    }

    public void setCod_cargo(int cod_cargo) {
        this.cod_cargo = cod_cargo;
    }

    public Date getDti_func_cargo() {
        return dti_func_cargo;
    }

    public void setDti_func_cargo(Date dti_func_cargo) {
        this.dti_func_cargo = dti_func_cargo;
    }
}
