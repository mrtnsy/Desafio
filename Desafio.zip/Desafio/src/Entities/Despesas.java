package Entities;

import java.util.Date;

public class Despesas {

    private int num_despesa;
    private int num_projeto;
    private Date dta_despesa;
    private float vlr_despesa;
    private String dsc_despesa;

    public Despesas(int num_despesa, int num_projeto, Date dta_despesa, float vlr_despesa, String dsc_despesa){

        this.num_despesa = num_despesa;
        this.num_projeto = num_projeto;
        this.dta_despesa = dta_despesa;
        this.vlr_despesa = vlr_despesa;
        this.dsc_despesa = dsc_despesa;
    }


    public int getNum_despesa() {
        return num_despesa;
    }

    public void setNum_despesa(int num_despesa) {
        this.num_despesa = num_despesa;
    }

    public int getNum_projeto() {
        return num_projeto;
    }

    public void setNum_projeto(int num_projeto) {
        this.num_projeto = num_projeto;
    }

    public Date getDta_despesa() {
        return dta_despesa;
    }

    public void setDta_despesa(Date dta_despesa) {
        this.dta_despesa = dta_despesa;
    }

    public float getVlr_despesa() {
        return vlr_despesa;
    }

    public void setVlr_despesa(float vlr_despesa) {
        this.vlr_despesa = vlr_despesa;
    }

    public String getDsc_despesa() {
        return dsc_despesa;
    }

    public void setDsc_despesa(String dsc_despesa) {
        this.dsc_despesa = dsc_despesa;
    }
}
