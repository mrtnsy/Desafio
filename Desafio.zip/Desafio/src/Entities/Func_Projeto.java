package Entities;

public class Func_Projeto {

    private int cod_funcionario;
    private int num_projeto;

    public Func_Projeto(int cod_funcionario, int num_projeto){

        this.cod_funcionario = cod_funcionario;
        this.num_projeto = num_projeto;

    }

    public int getCod_funcionario(){

        return cod_funcionario;
    }

    public void setCod_funcionario(int cod_funcionario){
        this.cod_funcionario = cod_funcionario;
    }

    public int getNum_projeto() {
        return num_projeto;
    }

    public void setNum_projeto(int num_projeto){
        this.num_projeto = num_projeto;
    }
}
